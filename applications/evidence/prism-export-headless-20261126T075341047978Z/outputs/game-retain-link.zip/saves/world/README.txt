Generated world-like bytes.
