module.exports={name:"rules-override-leaf",version:"1.0.0",file:__filename};
