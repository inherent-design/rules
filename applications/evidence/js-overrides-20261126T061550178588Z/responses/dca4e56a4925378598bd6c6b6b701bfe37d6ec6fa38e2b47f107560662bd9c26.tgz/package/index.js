module.exports={name:"rules-override-right",version:"1.0.0",file:__filename,leaf:require("rules-override-leaf")};
