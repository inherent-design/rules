module.exports={"name": "rules-sbom-prod", "value": "original"};
