Owned package contents fixture.
