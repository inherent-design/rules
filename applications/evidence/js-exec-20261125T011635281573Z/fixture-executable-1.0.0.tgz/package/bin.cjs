#!/usr/bin/env node
const fs=require('fs');const row={kind:"dependency",args:process.argv.slice(2),cwd:process.cwd()};fs.appendFileSync(process.env.FIXTURE_EFFECT_FILE,JSON.stringify(row)+'\n');console.log(JSON.stringify(row));
