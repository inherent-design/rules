module.exports = require("rules-workspace-fixture-npm-producer");
