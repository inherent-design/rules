module.exports = require("rules-workspace-fixture-pnpm-producer");
