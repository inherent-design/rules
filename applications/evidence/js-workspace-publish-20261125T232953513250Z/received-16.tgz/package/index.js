module.exports = require("rules-workspace-fixture-yarn-producer");
