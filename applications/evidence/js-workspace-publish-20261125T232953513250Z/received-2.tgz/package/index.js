module.exports = "producer:1.0.0";
