#!/bin/sh
printf %s 'Study '"'"' Ω'
