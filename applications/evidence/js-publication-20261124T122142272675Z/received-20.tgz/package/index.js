module.exports = "generated publication fixture";
