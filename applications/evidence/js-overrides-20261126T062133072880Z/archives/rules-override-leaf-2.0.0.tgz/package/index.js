module.exports={name:"rules-override-leaf",version:"2.0.0",file:__filename};
